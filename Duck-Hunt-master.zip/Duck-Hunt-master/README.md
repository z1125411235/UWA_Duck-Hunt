# Super Duck Hunt
For my first project in Unity I recreated Duck Hunt.

Play the final game here: 
https://codyanderson.itch.io/duck-hunt

![alt text](https://cdna.artstation.com/p/assets/images/images/015/158/594/large/cody-anderson-screenshot-448.jpg?1547276901)
