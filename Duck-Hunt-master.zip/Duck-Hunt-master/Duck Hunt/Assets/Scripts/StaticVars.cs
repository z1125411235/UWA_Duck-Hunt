﻿using UnityEngine;
using System.Collections;

public class StaticVars : MonoBehaviour
{
	public static bool noClick;
	public static int roundNum;
	public static int duckNum;
	public static bool paused = false;


}
